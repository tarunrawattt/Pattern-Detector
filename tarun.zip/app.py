"""
Streamlit front-end for the R360 Chart Pattern Identifier.

Run locally with:
    streamlit run app.py

Deploy for free on Streamlit Community Cloud by pushing this folder
(app.py + pattern_detector.py + requirements.txt) to a GitHub repo and
connecting it at https://share.streamlit.io
"""

import streamlit as st
import pandas as pd
from datetime import datetime

from pattern_detector import fetch_ohlc, detect_pattern, build_pattern_figure

st.set_page_config(
    page_title="R360 Chart Pattern Identifier",
    page_icon="📈",
    layout="wide",
)

# ── Session state: keeps a running table of everything checked this session ──
if "history" not in st.session_state:
    st.session_state.history = []

st.title("📈 R360 Chart Pattern Identifier")
st.caption(
    "Paste a research360.in stock chart link — the app fetches ~6 months of "
    "daily candles, scans the most recent ~3 months for the best-formed "
    "pattern (Ascending/Descending/Symmetrical Triangle, Rising/Falling "
    "Wedge), and draws it on the chart."
)

# ── Input row: text box + button ─────────────────────────────────────────────
col1, col2 = st.columns([5, 1])
with col1:
    link = st.text_input(
        "Paste your R360 stock link",
        placeholder="https://www.research360.in/charting?co_code=...&symbol=...&exchange=NSE&fromdate=&todate=&ntoken=",
        label_visibility="collapsed",
    )
with col2:
    run_clicked = st.button("Detect Pattern", type="primary", use_container_width=True)

# ── Run the pipeline on click ─────────────────────────────────────────────────
if run_clicked:
    if not link.strip():
        st.warning("Paste a stock link first.")
    else:
        with st.spinner("Fetching data and scanning for patterns..."):
            try:
                df, symbol = fetch_ohlc(link.strip())
                match = detect_pattern(df)
                fig = build_pattern_figure(df, symbol, match)
            except Exception as err:
                st.error(f"Something went wrong: {err}")
                df = symbol = match = fig = None

        if fig is not None:
            # ── Pattern name + score, shown prominently ──────────────────────
            if match:
                score_pct = match["score"] * 100
                st.success(
                    f"**{symbol}** — **{match['pattern'].replace('_', ' ')}**  "
                    f"(confidence score: {score_pct:.0f}%)"
                )
            else:
                st.info(f"**{symbol}** — No clear pattern in the recent window.")

            # ── The interactive chart ─────────────────────────────────────────
            st.plotly_chart(fig, use_container_width=False)

            # ── Log this run into the session's history table ────────────────
            st.session_state.history.insert(0, {
                "Time": datetime.now().strftime("%H:%M:%S"),
                "Symbol": symbol,
                "Pattern": match["pattern"].replace("_", " ") if match else "No clear pattern",
                "Score": f"{match['score']*100:.0f}%" if match else "—",
            })

# ── Recent results table (persists across runs this session) ────────────────
if st.session_state.history:
    st.subheader("Recent checks (this session)")
    st.dataframe(
        pd.DataFrame(st.session_state.history),
        use_container_width=True,
        hide_index=True,
    )
    if st.button("Clear history"):
        st.session_state.history = []
        st.rerun()
