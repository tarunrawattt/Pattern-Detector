"""
R360 Chart Pattern Identifier — MATH-ONLY (no ML), live rolling window.

Fetches ~6 months of daily candles for chart context, but pattern DETECTION
only searches the most recent ~3 months — a live recommendation should reflect
recent structure, not something that happened 5 months ago, and searching a
smaller domain is also cheaper. The matched pattern's end can sit a handful of
candles (roughly 5-10) before the very latest candle if that's genuinely the
best-formed recent shape — it is not forced to touch the last candle, nor
allowed to be a stale formation from deep in the older data.

Detects the best-formed of 5 patterns and draws it on the candlestick chart:
    Ascending Triangle, Descending Triangle, Symmetrical Triangle,
    Rising Wedge, Falling Wedge.

────────────────────────────────────────────────────────────────────────────
DECISION LOGIC (learned from real charts, calibrated per pattern)

For any candidate region we fit an UPPER trendline through the swing highs and a
LOWER trendline through the swing lows, then measure six things:

    Su   normalized slope of upper line   (%/candle, relative to avg price)
    Sl   normalized slope of lower line
    Fu   flatness of the highs   = std(swing-high prices) / pattern-height
    Fl   flatness of the lows    = std(swing-low  prices) / pattern-height
    C    convergence ratio       = gap_at_end / gap_at_start   (<1 = converging)
    T    touch quality           = how many real swings each line hugs, how tight

A line is a "flat side" when its swings are clustered at one level (Fu/Fl small),
NOT merely when its slope rounds to zero.

    Ascending Triangle : upper FLAT (Fu small) + lower rising.
                         convergence preferred, NOT required (can be a wide box).
    Descending Triangle: lower FLAT (Fl small) + upper falling.
                         convergence preferred, NOT required (can be a wide box).
    Symmetrical Triangle: upper down + lower up, neither side flat.
                          convergence MANDATORY (pinches to an apex).
    Rising Wedge       : both up, neither side flat, lower steeper than upper.
                         convergence MANDATORY  (else it's a rising channel).
    Falling Wedge      : both down, neither side flat, upper steeper than lower.
                         convergence MANDATORY  (else it's a falling channel).

The two thin-but-critical splits are decided on the UPPER/LOWER *flatness*, not a
slope-sign coin-flip:
    Ascending  vs Rising Wedge  → is the upper line FLAT or gently RISING?
    Descending vs Falling Wedge → is the lower line FLAT or gently FALLING?

OUTPUT: exactly one pattern — the highest-scoring well-formed formation in the
window — or "No clear pattern" if nothing clears the score floor.

DRAWING: trendlines are drawn THROUGH the real swing touch-points (no envelope
buffer; stray wicks may poke out). The pattern ends at its true completion, which
may sit a few candles before the latest candle (never stretched to the last bar,
never truncated early).
────────────────────────────────────────────────────────────────────────────
"""

import time
import requests
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import urllib.parse
from pathlib import Path
from datetime import datetime, timedelta
from scipy.signal import find_peaks

SCRIPT_DIR = Path(__file__).parent.resolve()

# ── Window sizing ─────────────────────────────────────────────────────────
FETCH_DAYS  = 182   # ~6 months fetched & shown on the chart, for context
FETCH_RETRIES = 3    # network retry attempts before giving up
FETCH_RETRY_DELAY = 2.0   # seconds between retries
DETECT_DAYS = 91    # ~3 months — pattern DETECTION only searches this most
                     # recent slice of the fetched data (efficiency + relevance:
                     # a live call should be about recent structure, not a shape
                     # from 5 months back). The chart still displays all 6 months.

# ── Paste your R360 stock link here ─────────────────────────────────────────
LINK_TO_SCRAPE = "https://www.research360.in/charting?co_code=41356&symbol=41356&exchange=NSE&fromdate=&todate=&ntoken="

# ── Tunable thresholds (calibrated from the StockEdge reference charts) ──────
FLAT_SLOPE   = 0.10   # |normalized slope| <= this  → slope is "flat-ish"  (%/candle)
FLAT_RATIO   = 0.55   # a line counts as "the flat side" when its flatness is this
                       # fraction (or less) of the OTHER line's flatness — relative,
                       # not an absolute cutoff, so it adapts to each stock's own
                       # volatility instead of failing on noisy real data.
CONV_GATE    = 0.85   # gap_end/gap_start <  this   → lines are "converging"
PARALLEL_HI  = 1.15   # gap_end/gap_start >  this   → diverging (broadening)
SWING_DIST   = 3      # min candles between detected swings
MIN_REGION   = 15     # a pattern must span at least this many candles
MIN_SWINGS   = 3      # each trendline needs at least this many swing points —
                       # 3+ genuine touches filters out coincidental noise shapes
SCORE_FLOOR  = 0.45   # below this, report "No clear pattern"
TOUCH_DENSITY_TARGET = 0.12   # ~1 real touch per 8 candles -> full marks
STEEP_REFERENCE = 0.40   # %/candle slope-gap that counts as a "strongly steep"
                          # wedge, for scoring the two lines' slope difference
MIDLINE_FLAT_MAX = 0.25   # symmetrical's true signature: the pattern's CENTER
                           # (avg of upper+lower) must stay roughly where it
                           # started — one line falls about as much as the
                           # other rises, so buyers/sellers are in genuine
                           # doubt, unlike a wedge where the whole channel
                           # drifts one way. Max allowed center drift, as a
                           # fraction of pattern height.
MIN_OPPOSITE_SLOPE = 0.03 # %/candle — much looser than FLAT_SLOPE (0.10):
                           # symmetrical only needs the two lines genuinely
                           # leaning opposite ways, not each clearing the
                           # stricter "clearly up/down" bar used elsewhere.
VOLUME_DECLINE_TARGET = 0.01   # ~1%/candle average volume decline -> full
                                # confirmation credit (textbook: volume shrinks
                                # as a triangle/wedge forms)
LEAD_IN_CANDLES = 8   # candles checked BEFORE the pattern start for a genuine
                       # trend leading in — triangles/wedges are textbook
                       # CONTINUATION patterns, a real pause mid-trend, not a
                       # shape that appears out of nowhere in flat noise.
RECENCY_GRACE = 25    # MIDDLE GROUND, chosen after measuring the tradeoff:
                       #   grace=60 (previous) -> median pattern ends ~28 candles
                       #     back, only 25% within 10 candles of today -- too
                       #     stale-feeling for a "live" call, even though it gave
                       #     the best triangle/wedge balance (57%/41%).
                       #   grace=15 -> median ends ~6 candles back (close to
                       #     "today"), but reopens the wedge bias (68%/30%),
                       #     since a wedge can trivially claim the last few
                       #     candles again.
                       #   grace=25, tau=12 -> median ends ~12 candles back,
                       #     41% within 10 / 74% within 20, wedge/triangle
                       #     roughly balanced (54%/44%) -- close to "recent" AND
                       #     keeps the pattern-balance fix from being undone.
RECENCY_TAU  = 12.0

# ── Chart display sizing (cosmetic only — no effect on detection/logic) ─────
YAXIS_BOTTOM_PAD_FRAC = 0.35  # extra room BELOW the lowest low, as a fraction
                               # of the candle range — generous, so a lower
                               # trendline near the bottom has visible room
YAXIS_TOP_PAD_FRAC    = 0.10  # extra room ABOVE the highest high — modest,
                               # since the top rarely needs much extra space
CHART_WIDTH  = 1400            # explicit width so the full pattern is always
CHART_HEIGHT = 700              # visible, not cropped by a container's default size


# ── Step 1: Fetch OHLC  (kept as-is — this is the data source, not logic) ────
def fetch_ohlc(link):
    parsed  = urllib.parse.urlparse(link)
    params  = urllib.parse.parse_qs(parsed.query)
    symbol  = params.get('symbol',  [None])[0]
    co_code = params.get('co_code', [None])[0]
    if not symbol:
        raise ValueError("Could not find 'symbol' in link!")

    print(f"[1/3] Fetching OHLCV data for: {symbol} (co_code={co_code})")
    current_unix = int(time.time())
    past_unix    = current_unix - (FETCH_DAYS * 24 * 60 * 60)  # 6 mahine pehle

    # IMPORTANT: do NOT append co_code to this call. Verified against the live
    # API: a request WITH co_code returns only o/h/l/c/s/t (no volume) — but the
    # exact same request using just `symbol` (the real text ticker, e.g.
    # "SUMICHEM") returns the full response including a `v` (volume) array,
    # matching what the R360 web widget itself calls. Including co_code silently
    # suppresses volume, so it's deliberately left out here.
    api_url = (
        f"https://research360api.motilaloswal.com/api/getcharts/history"
        f"?symbol={symbol}&resolution=1D"
        f"&from={past_unix}&to={current_unix}"
        f"&countback={FETCH_DAYS}&currencyCode=INR"
    )
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Referer":    "https://www.research360.in/",
        "Accept":     "application/json",
    }

    # Retry with backoff — a transient API hiccup shouldn't kill a live run.
    last_err = None
    r = None
    for attempt in range(FETCH_RETRIES):
        try:
            r = requests.get(api_url, headers=headers, timeout=15)
            if r.status_code == 200:
                break
            last_err = ConnectionError(f"API returned {r.status_code}: {r.text[:200]}")
        except requests.RequestException as ex:
            last_err = ex
        if attempt < FETCH_RETRIES - 1:
            print(f"  \u26a0\ufe0f  Fetch attempt {attempt+1} failed, retrying...")
            time.sleep(FETCH_RETRY_DELAY)
    else:
        raise last_err
    if r is None or r.status_code != 200:
        raise last_err if last_err else ConnectionError("Fetch failed after retries")

    raw = r.json()
    if 't' not in raw:
        raise ValueError(f"Unexpected response: {list(raw.keys())}")

    has_volume = 'v' in raw and raw['v'] is not None
    df = pd.DataFrame({
        'Date':  pd.to_datetime(raw['t'], unit='s'),
        'Open':  [float(x) for x in raw['o']],
        'High':  [float(x) for x in raw['h']],
        'Low':   [float(x) for x in raw['l']],
        'Close': [float(x) for x in raw['c']],
        'Volume': ([float(x) for x in raw['v']] if has_volume
                   else [np.nan] * len(raw['t'])),
    }).set_index('Date')

    # API kabhi kabhi from= ignore karke purana data bhi bhej deta hai
    # Isliye strictly sirf last 6 mahine (FETCH_DAYS) ka data rakho — date se filter karo
    cutoff    = pd.Timestamp.utcnow().tz_localize(None) - timedelta(days=FETCH_DAYS)
    df_sliced = df[df.index >= cutoff]

    # Agar itna data nahi mila (recently listed stock), poora use karo
    if len(df_sliced) < 10:
        df_sliced = df

    print(f"  \u2705 Data loaded: {len(df_sliced)} candles | "
          f"{df_sliced.index[0].date()} \u2192 {df_sliced.index[-1].date()} | "
          f"volume {'available' if has_volume else 'NOT available'}")
    return df_sliced, symbol


# ── Step 2: Geometry helpers (shared by every pattern check) ─────────────────
def _fit_line(idx, values):
    """Least-squares line through (idx, values). Returns (slope, intercept)."""
    slope, intercept = np.polyfit(idx.astype(float), values.astype(float), 1)
    return float(slope), float(intercept)


def _direction(slope_norm):
    """'up' / 'down' / 'flat' from a normalized (%/candle) slope."""
    if slope_norm >  FLAT_SLOPE:
        return "up"
    if slope_norm < -FLAT_SLOPE:
        return "down"
    return "flat"


def _swings_in(highs, lows, s, e):
    """
    Swing highs / lows strictly inside window [s, e] (inclusive), returned as
    absolute indices into the full arrays. Endpoints are always included as
    anchor candidates so short/monotonic legs still get a 2-point line.
    """
    seg_hi = highs[s:e + 1]
    seg_lo = lows[s:e + 1]

    peaks, _   = find_peaks(seg_hi,  distance=SWING_DIST)
    troughs, _ = find_peaks(-seg_lo, distance=SWING_DIST)

    peaks   = [s + int(p) for p in peaks]
    troughs = [s + int(t) for t in troughs]

    # Always allow the window edges as anchors (a trendline touch can sit there)
    for edge in (s, e):
        if edge not in peaks:
            peaks.append(edge)
        if edge not in troughs:
            troughs.append(edge)

    return np.array(sorted(set(peaks))), np.array(sorted(set(troughs)))


def _lead_in_strength(closes, s):
    """
    How strong and directionally consistent is the trend in the CLOSES just
    before the pattern's start `s`? Triangles/wedges are continuation patterns —
    a genuine one has a real trend leading into it, not flat noise. Returns a
    0-1 score (0 = no/insufficient lead-in, 1 = strong clean trend).
    Neutral (0.5) if there isn't enough history before `s` to judge.
    """
    lead_start = s - LEAD_IN_CANDLES
    if lead_start < 0:
        return 0.5   # not enough history before the pattern — stay neutral

    seg = closes[lead_start:s + 1]
    if len(seg) < 4:
        return 0.5

    avg_price = float(np.mean(seg))
    if avg_price <= 0:
        return 0.5

    idx = np.arange(len(seg), dtype=float)
    slope, _ = _fit_line(idx, seg)
    slope_norm = abs(slope) / avg_price * 100.0        # %/candle magnitude
    magnitude = float(np.clip(slope_norm / 0.30, 0.0, 1.0))  # 0.30%/candle -> full marks

    # Directional consistency: fraction of candle-to-candle moves that agree
    # with the overall lead-in direction (filters "big slope from one jump").
    diffs = np.diff(seg)
    overall_dir = np.sign(slope) if slope != 0 else 0.0
    agree = np.sum(np.sign(diffs) == overall_dir) if overall_dir != 0 else 0
    consistency = agree / max(1, len(diffs))

    return float(np.clip(0.5 * magnitude + 0.5 * consistency, 0.0, 1.0))


def _volume_confirmation(volumes, s, e):
    """
    Textbook confirmation, sourced from real technical-analysis definitions:
    volume should DECLINE while a triangle/wedge forms (shrinking participation
    as the range narrows), then spike on breakout. We only have the formation
    period here, so this checks the declining-volume half of that signature.
    Applies identically to all 5 patterns — this is a shape-agnostic
    confirmation, not something that favors one pattern over another.
    Returns a 0-1 score; 0.5 (neutral) if volume data isn't usably available,
    so absent/gappy volume never penalizes an otherwise well-formed pattern.

    Tolerates PARTIAL gaps: a stray missing candle (holiday, API hiccup) only
    drops that one point, it doesn't blank out the whole window's signal.
    """
    seg_raw = volumes[s:e + 1]
    if seg_raw is None or len(seg_raw) < 4:
        return 0.5

    valid = ~np.isnan(seg_raw)
    if np.sum(valid) < max(4, int(0.7 * len(seg_raw))):
        return 0.5   # too many gaps to trust a trend from what's left

    seg = seg_raw[valid]
    idx = np.arange(len(seg_raw), dtype=float)[valid]   # keep real spacing
    avg_vol = float(np.mean(seg))
    if avg_vol <= 0:
        return 0.5

    slope, _ = _fit_line(idx, seg)
    slope_norm = slope / avg_vol   # fractional change in volume per candle

    # Declining volume -> confirming. Flat or rising -> weaker confirmation,
    # but never a hard rejection (some genuine patterns still break this).
    if slope_norm < 0:
        return float(np.clip(-slope_norm / VOLUME_DECLINE_TARGET, 0.0, 1.0))
    return 0.0


def _evaluate_window(highs, lows, closes, volumes, avg_price, s, e, n):
    """
    Fit both trendlines in [s, e], measure the six quantities, and package a
    metrics dict. Returns None if the window can't support two trendlines.
    """
    if e - s + 1 < MIN_REGION:
        return None

    peak_idx, trough_idx = _swings_in(highs, lows, s, e)
    if len(peak_idx) < MIN_SWINGS or len(trough_idx) < MIN_SWINGS:
        return None

    up_slope, up_int = _fit_line(peak_idx,   highs[peak_idx])
    lo_slope, lo_int = _fit_line(trough_idx, lows[trough_idx])

    height = float(highs[s:e + 1].max() - lows[s:e + 1].min())
    if height <= 0:
        return None

    # Normalized slopes (%/candle) so any price level is comparable
    Su = up_slope / avg_price * 100.0
    Sl = lo_slope / avg_price * 100.0

    # Flatness = spread of the swing prices around their level, vs pattern height
    Fu = float(np.std(highs[peak_idx]))   / height
    Fl = float(np.std(lows[trough_idx]))  / height

    # Convergence: gap between the lines at the two ends of the window
    gap_start = (up_slope * s + up_int) - (lo_slope * s + lo_int)
    gap_end   = (up_slope * e + up_int) - (lo_slope * e + lo_int)
    if gap_start <= 0:
        return None                      # lines already crossed at the start
    C = gap_end / gap_start

    # Touch quality: fraction of swings hugging their line, and how tightly
    up_res = np.abs(highs[peak_idx]   - (up_slope * peak_idx   + up_int))
    lo_res = np.abs(lows[trough_idx]  - (lo_slope * trough_idx + lo_int))
    tol    = height * 0.05
    up_touch = int(np.sum(up_res <= tol))
    lo_touch = int(np.sum(lo_res <= tol))
    tightness = 1.0 - min(1.0, (up_res.mean() + lo_res.mean()) / (2 * height))
    # Midline drift: does the pattern's CENTER (avg of upper+lower) stay put,
    # or does the whole channel drift one way? This is the real signature that
    # separates genuine indecision (symmetrical) from a directional wedge.
    up_y_s, up_y_e = up_slope * s + up_int, up_slope * e + up_int
    lo_y_s, lo_y_e = lo_slope * s + lo_int, lo_slope * e + lo_int
    mid_start = (up_y_s + lo_y_s) / 2.0
    mid_end   = (up_y_e + lo_y_e) / 2.0
    midline_drift_ratio = abs(mid_end - mid_start) / height

    touch_count = up_touch + lo_touch

    lead_in = _lead_in_strength(closes, s)
    volume_conf = _volume_confirmation(volumes, s, e)

    return {
        "s": s, "e": e,
        "peak_idx": peak_idx, "trough_idx": trough_idx,
        "up_slope": up_slope, "up_int": up_int,
        "lo_slope": lo_slope, "lo_int": lo_int,
        "Su": Su, "Sl": Sl, "Fu": Fu, "Fl": Fl, "C": C,
        "height": height, "midline_drift_ratio": midline_drift_ratio,
        "up_touch": up_touch, "lo_touch": lo_touch,
        "touch_count": touch_count, "tightness": tightness,
        "lead_in": lead_in, "volume_conf": volume_conf,
    }


# ── Step 3: Classify a window into one of the 5 patterns (or None) ───────────
def _classify(m):
    """
    Apply the decision grid to a metrics dict `m`.
    Returns (pattern_name, quality_0_to_1) or None.
    `quality` reflects how *textbook* the shape is (before touch/recency scoring).
    """
    Su, Sl, Fu, Fl, C = m["Su"], m["Sl"], m["Fu"], m["Fl"], m["C"]

    # Relative flatness: a line is "the flat side" when it's meaningfully flatter
    # than the OTHER line on this same chart (Fu vs Fl compared to each other),
    # not when it clears a fixed universal number — real noisy data has no
    # absolute "flat" level, so this adapts per-stock instead of locking triangles
    # out entirely on volatile charts.
    eps = 1e-9
    upper_flat = Fu <= FLAT_RATIO * (Fl + eps)
    lower_flat = Fl <= FLAT_RATIO * (Fu + eps)
    up_dir = _direction(Su)
    lo_dir = _direction(Sl)

    converging = C < CONV_GATE
    # convergence quality in [0,1]: C=CONV_GATE→0, C=0 (perfect apex)→1
    conv_q = float(np.clip((CONV_GATE - C) / CONV_GATE, 0.0, 1.0))

    # 1) FLAT-SIDE TRIANGLES — flat side is mandatory, convergence is a bonus.
    #    Ascending: upper relatively flat + lower rising (and not also "flat").
    if upper_flat and (not lower_flat) and lo_dir == "up":
        flatness_edge = 1.0 - min(1.0, Fu / (Fl + eps))   # how much flatter than Fl
        quality = 0.55 + 0.30 * flatness_edge + 0.15 * conv_q
        return "Ascending_Triangle", float(np.clip(quality, 0, 1))

    #    Descending: lower relatively flat + upper falling (and not also "flat").
    if lower_flat and (not upper_flat) and up_dir == "down":
        flatness_edge = 1.0 - min(1.0, Fl / (Fu + eps))
        quality = 0.55 + 0.30 * flatness_edge + 0.15 * conv_q
        return "Descending_Triangle", float(np.clip(quality, 0, 1))

    # 2) CONVERGING PATTERNS (no flat side) — convergence is mandatory.
    if not converging:
        return None
    if upper_flat or lower_flat:
        return None    # a flat side here means it was a triangle handled above

    #    Symmetrical: TRUE indecision — upper genuinely leans down, lower
    #    genuinely leans up (a looser, dedicated check than the generic
    #    up/down/flat bucketing used elsewhere — symmetrical only needs the
    #    two lines opposing each other, not each independently clearing the
    #    stricter "clearly directional" bar). Converging is still mandatory.
    #    The DEFINING extra requirement: the pattern's CENTER must stay flat —
    #    one line falls about as much as the other rises, so price ends up
    #    near where it started (real buyer/seller indecision), unlike a wedge
    #    where the whole channel visibly drifts one way even while narrowing.
    if (Su < -MIN_OPPOSITE_SLOPE and Sl > MIN_OPPOSITE_SLOPE
            and m["midline_drift_ratio"] <= MIDLINE_FLAT_MAX):
        midline_q = 1.0 - min(1.0, m["midline_drift_ratio"] / MIDLINE_FLAT_MAX)
        quality = 0.55 + 0.25 * conv_q + 0.20 * midline_q
        return "Symmetrical_Triangle", float(np.clip(quality, 0, 1))

    #    Rising wedge: both up, lower steeper than upper (lines closing upward).
    if up_dir == "up" and lo_dir == "up" and Sl > Su:
        # Steepness = how big the slope GAP is, scaled against a fixed reference
        # — NOT divided by Su itself. Su can legitimately be tiny (just barely
        # over the "up" threshold), and dividing by a near-zero number let this
        # blow up to a maxed-out 1.0 for an ordinary wedge, not a genuinely
        # extreme one — a real scoring bug, not a meaningful measurement.
        steep = min(1.0, (Sl - Su) / STEEP_REFERENCE)
        quality = 0.50 + 0.30 * conv_q + 0.20 * steep
        return "Rising_Wedge", float(np.clip(quality, 0, 1))

    #    Falling wedge: both down, upper steeper than lower (lines closing down).
    if up_dir == "down" and lo_dir == "down" and Su < Sl:
        steep = min(1.0, (Sl - Su) / STEEP_REFERENCE)
        quality = 0.50 + 0.30 * conv_q + 0.20 * steep
        return "Falling_Wedge", float(np.clip(quality, 0, 1))

    return None


def _score(m, quality, n):
    """
    Blend shape-quality with touch DENSITY, tightness, lead-in, and recency.

    Touch and span are measured as DENSITY/ADEQUACY, not raw count or raw
    length: "both lines drift the same way and loosely converge" (wedge) is
    trivially satisfied across an entire long window, so it racks up more raw
    touches and more raw span just by covering more calendar days — not because
    it's a truer pattern. Rewarding raw count/length let window LENGTH silently
    decide the winner instead of shape quality. Rewarding density (touches per
    candle) and adequacy (span past a reasonable minimum, not "longer is always
    better") removes that automatic advantage.
    """
    gap_from_now = max(0, (n - 1) - m["e"] - RECENCY_GRACE)
    recency = float(np.exp(-gap_from_now / RECENCY_TAU))

    span_len = m["e"] - m["s"] + 1
    touch_density = m["touch_count"] / span_len
    touch = min(1.0, touch_density / TOUCH_DENSITY_TARGET)

    # Span is a floor, not a ladder: any window past ~2x MIN_REGION is "long
    # enough" — being longer still doesn't earn extra credit, which stops
    # sheer window length from being a scoring lever.
    span = min(1.0, span_len / (2.0 * MIN_REGION))

    return (0.11 * recency +
            0.42 * quality +
            0.15 * m["lead_in"] +
            0.15 * touch +
            0.06 * m["tightness"] +
            0.04 * span +
            0.07 * m["volume_conf"])


# ── Step 4: Search the whole window for the single best-formed pattern ───────
def detect_pattern(df):
    print("[2/3] Scanning most recent window for the best-formed pattern...")
    highs  = df['High'].values.astype(float)
    lows   = df['Low'].values.astype(float)
    closes = df['Close'].values.astype(float)
    volumes = (df['Volume'].values.astype(float) if 'Volume' in df.columns
               else np.full(len(df), np.nan))
    avg_price = float(df['Close'].mean())
    n = len(df)

    # Restrict the SEARCH domain to the most recent ~3 months (DETECT_DAYS) of
    # the fetched ~6 months (FETCH_DAYS) — efficiency, and a live call should be
    # about recent structure, not a shape from months back. The older months are
    # still kept in `highs`/`lows`/`closes` (unsliced) so lead-in trend checks
    # and the displayed chart both retain full 6-month context.
    detect_cutoff   = df.index[-1] - pd.Timedelta(days=DETECT_DAYS)
    detect_start_idx = int(np.searchsorted(df.index.values, np.datetime64(detect_cutoff)))
    detect_start_idx = min(detect_start_idx, max(0, n - MIN_REGION))

    # Candidate anchors: every detected swing extreme within the detection
    # window + the window edges (the pattern's start/end must lie in this
    # recent slice; older data is not eligible to anchor a live pattern).
    all_peaks, _   = find_peaks(highs,  distance=SWING_DIST)
    all_troughs, _ = find_peaks(-lows,  distance=SWING_DIST)
    recent_peaks   = [p for p in all_peaks   if p >= detect_start_idx]
    recent_troughs = [t for t in all_troughs if t >= detect_start_idx]
    starts = sorted(set([detect_start_idx] + recent_peaks + recent_troughs))
    ends   = sorted(set(recent_peaks + recent_troughs + [n - 1]))

    # ── Bias fix ──────────────────────────────────────────────────────────
    # "Both lines same direction + loosely converging" (wedge) is satisfied by
    # far more overlapping candidate windows than the rarer triangle/symmetrical
    # conditions. Picking one global best across ALL windows unfairly compares
    # "best of ~1700 tries" against "best of ~60 tries" — the pattern with more
    # matching windows wins more often on sample-size alone, not because it's
    # the truer shape. Fix: find the single best candidate PER PATTERN TYPE
    # first, then let those (at most 5) finalists compete on equal footing.
    finalists = {}   # pattern_name -> (score, metrics_dict)

    for s in starts:
        if s > n - MIN_REGION:
            continue
        for e in ends:
            if e - s + 1 < MIN_REGION:
                continue
            m = _evaluate_window(highs, lows, closes, volumes, avg_price, s, e, n)
            if m is None:
                continue
            result = _classify(m)
            if result is None:
                continue
            pattern, quality = result
            sc = _score(m, quality, n)
            if pattern not in finalists or sc > finalists[pattern][0]:
                finalists[pattern] = (sc, m, quality)

    if not finalists:
        print(f"  \u26a0\ufe0f  No clear pattern (no window matched any of the 5 shapes).")
        return None

    best_pattern, (best_score, best, best_quality) = max(
        finalists.items(), key=lambda kv: kv[1][0]
    )

    # Tie-break toward the more SPECIFIC triangle on a genuine near-tie only.
    # A flat-side triangle needs an extra, harder-to-satisfy condition (a truly
    # flatter side) than its wedge counterpart — so on a close call it's the
    # better-evidenced hypothesis (don't let the more generic shape win by
    # default). But when the wedge wins by a REAL margin, that margin reflects
    # genuine extra evidence (steeper convergence, tighter fit) — overriding a
    # clear signal just to manufacture more triangle calls would be dishonest,
    # so only the two SPECIFIC counterpart pairs are compared, and only within
    # TIE_MARGIN (empirically: most wedge wins over their triangle counterpart
    # are this close; a real, decisive wedge win sits well above it and is left
    # untouched).
    TIE_MARGIN = 0.05
    counterpart = {"Rising_Wedge": "Ascending_Triangle",
                   "Falling_Wedge": "Descending_Triangle"}
    if best_pattern in counterpart:
        tri = counterpart[best_pattern]
        if tri in finalists and (best_score - finalists[tri][0]) < TIE_MARGIN:
            best_score, best, best_quality = finalists[tri]
            best_pattern = tri

    if best_score < SCORE_FLOOR:
        print(f"  \u26a0\ufe0f  No clear pattern (best score "
              f"{best_score:.2f} < floor {SCORE_FLOOR}).")
        return None

    best["pattern"] = best_pattern
    best["score"]   = best_score
    print(f"  \u2705 Best: {best_pattern}  (score {best_score:.2f})")
    print(f"     region candles {best['s']}\u2192{best['e']}  |  "
          f"Su={best['Su']:+.3f}%  Sl={best['Sl']:+.3f}%  "
          f"Fu={best['Fu']:.3f}  Fl={best['Fl']:.3f}  C={best['C']:.2f}  "
          f"touches={best['touch_count']}")
    print(f"     (finalists considered: "
          f"{', '.join(f'{k}={v[0]:.2f}' for k, v in sorted(finalists.items(), key=lambda kv: -kv[1][0]))})")
    return best


# ── Step 5: Draw the matched pattern on the chart ────────────────────────────
def _tight_envelope_line(anchor_idx, bound_values, s, e, is_upper):
    """
    Find the TIGHTEST straight boundary line that (a) touches real extreme
    points and (b) still contains every candle in [s, e] — instead of fitting a
    line then padding it outward by a single constant everywhere. A constant
    pad makes the drawn lines keep the same gap at every point even where the
    true price action narrows, so a genuinely converging pattern gets drawn as
    a stiff parallelogram instead of a triangle. Anchoring on real touches lets
    the line narrow wherever the price structure actually narrows.

    `anchor_idx`   candidate touch-point indices (e.g. swing peaks for the
                   upper line, swing troughs for the lower line) — real pivots
                   are the natural points a boundary line should rest on.
    `bound_values` the full High or Low array (line must stay outside these).
    `is_upper`     True: line must sit at/above every value in [s, e].
                   False: line must sit at/below every value in [s, e].

    Returns (slope, intercept). Falls back to a regression+offset line (the
    old safe method) if no anchor pair yields a valid tight bound.
    """
    span_vals = bound_values[s:e + 1]
    span_idx  = np.arange(s, e + 1)
    anchors   = np.array(sorted(set(int(a) for a in anchor_idx if s <= a <= e)))

    best = None   # (width, slope, intercept)
    for a_i in range(len(anchors)):
        for b_i in range(a_i + 1, len(anchors)):
            i, j = anchors[a_i], anchors[b_i]
            if j == i:
                continue
            slope = (bound_values[j] - bound_values[i]) / (j - i)
            intercept = bound_values[i] - slope * i
            line_vals = slope * span_idx + intercept
            valid = (np.all(span_vals <= line_vals + 1e-6) if is_upper
                     else np.all(span_vals >= line_vals - 1e-6))
            if valid:
                width = j - i
                if best is None or width > best[0]:
                    best = (width, slope, intercept)

    if best is not None:
        return best[1], best[2]

    # Fallback: regression line through the anchors, padded by the single
    # worst violation (guarantees containment even in an odd edge case).
    slope, intercept = _fit_line(anchors, bound_values[anchors])
    fit_vals = slope * span_idx + intercept
    if is_upper:
        pad = max(0.0, float(np.max(span_vals - fit_vals)))
        return slope, intercept + pad
    else:
        pad = max(0.0, float(np.max(fit_vals - span_vals)))
        return slope, intercept - pad


def build_pattern_figure(df, symbol, match):
    """
    Builds and returns the Plotly figure (candlestick + matched pattern
    overlay, or a plain candlestick with a "no pattern" title). Does NOT
    show or save anything — callers (a script, a Streamlit app, etc.)
    decide what to do with the returned figure.
    """
    dates = df.index.strftime('%Y-%m-%d').tolist()

    fig = go.Figure()
    fig.add_trace(go.Candlestick(
        x=dates,
        open=df['Open'].tolist(),  high=df['High'].tolist(),
        low=df['Low'].tolist(),    close=df['Close'].tolist(),
        name=symbol,
        increasing_line_color='#26a69a',
        decreasing_line_color='#ef5350',
    ))

    if match is None:
        title = f"{symbol} \u2014 <b>No clear pattern</b> (recent {DETECT_DAYS}-day window)"
    else:
        pattern = match["pattern"]
        s, e = match["s"], match["e"]

        highs = df['High'].values.astype(float)
        lows  = df['Low'].values.astype(float)

        # Tight envelope: each line anchors on real extreme touch points (swing
        # highs for the upper line, swing lows for the lower) and is the
        # WIDEST such line that still contains every candle — not a fitted
        # slope pushed out by one constant pad. This lets the drawn lines
        # genuinely narrow toward each other wherever the true price action
        # narrows (a real triangle apex), instead of keeping a fixed parallel
        # gap end to end. Falls back to a safe padded regression line if no
        # anchor pair alone can bound every candle.
        up_slope, up_int = _tight_envelope_line(
            match["peak_idx"], highs, s, e, is_upper=True)
        lo_slope, lo_int = _tight_envelope_line(
            match["trough_idx"], lows, s, e, is_upper=False)

        x_ends       = np.array([s, e], dtype=float)
        upper_y_ends = up_slope * x_ends + up_int
        lower_y_ends = lo_slope * x_ends + lo_int
        region_dates = [dates[s], dates[e]]

        # Shaded region between the two envelope lines over the pattern span
        fig.add_trace(go.Scatter(
            x=region_dates + region_dates[::-1],
            y=list(upper_y_ends) + list(lower_y_ends[::-1]),
            fill='toself',
            fillcolor='rgba(100, 150, 255, 0.15)',
            line=dict(color='rgba(0,0,0,0)'),
            name=pattern, showlegend=True,
        ))
        fig.add_trace(go.Scatter(
            x=region_dates, y=upper_y_ends, mode='lines',
            line=dict(color='#2196F3', width=2, dash='dash'),
            name='Upper trendline',
        ))
        fig.add_trace(go.Scatter(
            x=region_dates, y=lower_y_ends, mode='lines',
            line=dict(color='#FF5722', width=2, dash='dash'),
            name='Lower trendline',
        ))
        title = (f"{symbol} \u2014 <b>{pattern}</b>  "
                 f"(score {match['score']*100:.0f}%)")

    # ── Y-axis padding: ASYMMETRIC — more room below, less above ───────────
    price_range = df['High'].max() - df['Low'].min()
    bottom_pad  = price_range * YAXIS_BOTTOM_PAD_FRAC
    top_pad     = price_range * YAXIS_TOP_PAD_FRAC

    fig.update_layout(
        title=dict(text=title, font=dict(size=16)),
        template='plotly_white',
        xaxis_rangeslider_visible=False,
        yaxis=dict(side='right', title='Price (INR)',
                   range=[df['Low'].min() - bottom_pad,
                          df['High'].max() + top_pad]),
        width=CHART_WIDTH,
        height=CHART_HEIGHT,
    )
    return fig


def draw_pattern_on_chart(df, symbol, match):
    """Standalone-script convenience wrapper: build the figure, save a PNG
    (best-effort), and show it. Streamlit (or any other caller) should call
    build_pattern_figure() directly instead and handle display itself."""
    print(f"\n[3/3] Building chart for {symbol}...")
    fig = build_pattern_figure(df, symbol, match)

    out_dir   = SCRIPT_DIR / "predictions"
    out_dir.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    label     = match["pattern"] if match else "NoPattern"
    png_path  = out_dir / f"{symbol}_{label}_{timestamp}.png"
    try:
        fig.write_image(str(png_path))
        print(f"  Saved: {png_path}")
    except Exception as err:                    # kaleido missing etc. — non-fatal
        print(f"  (Could not save PNG: {err})")
    fig.show()


# ── Main ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    df, symbol = fetch_ohlc(LINK_TO_SCRAPE)
    match      = detect_pattern(df)
    draw_pattern_on_chart(df, symbol, match)

    if match:
        print(f"\n\u2705 Final: {match['pattern']}  |  Score: {match['score']*100:.0f}%")
    else:
        print("\n\u2139\ufe0f  Final: No clear recent pattern in the last "
              f"{DETECT_DAYS} days.")
